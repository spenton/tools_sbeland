

PLOTTING ROUTINES
-----------------
plot_obc_event_irradiance_discontinuities.pro: Plots irradiance discontinuity, as a function of wavelength, for a specified OBC event.
plot_all_obc_event_irradiance_discontinuities.pro: Calls plot_obc_event_irradiance_discontinuities.pro for the first 9 OBC events.
plot_all_obc_event_raypath_corrections_with_parameters.pro: A wrapper for get_obc_raypath_corrections.pro, which, in addition to
  determining OBC event raypath corrections, generates a series of plots for each OBC event, including pre-event raypath (a0) as a
  function of wavelength, post-event (i.e., "corrected") raypath (a1) as a function of wavelength, a1 vs a0, the uncorrected irradiance
  OBC event discontinuity as a function of wavelength, kappa as a function of wavelength, degradation column as a function of wavelength,
  pre- and post-event prism degradation as a function of wavelength, post-event prism degradation vs pre-event prism degradation, and
  tau as a function of wavelength.


OBC EVENT IRRADIANCE DISCONTINUITY ALGORITHMS - Used to quantify and/or plot OBC event irradiance discontinuities
-----------------------------------------------------------------------------------------------------------------
get_obc_event_irradiance_discontinuities.pro: Determines the OBC event irradiance discontinuity for a specified sensor and wavelength.
  Must be used with a wrapper (described below) to generate irradiance discontinuities as a function of wavelength.
wrapper_get_obc_event_irradiance_discontinuities.pro: Loops through wavelengths (SORCE Mission Day 453 as reference) and calls
  get_obc_event_irradiance_discontinuities.pro at each wavelength. Used to generate an ASCII output file (table) of irradiance
  discontinuities at each wavelength for each OBC event.


RAYPATH ALGORITHMS - Determines raypath adjustments necessary to align pre- and post-OBC event calibrated irradiances
---------------------------------------------------------------------------------------------------------------------
get_obc_event_raypath_corrections.pro: Creates an ASCII file (table) of raypath-related parameters at a series of wavelengths for a specified OBC event.
  Table parameters include wavelength, degradation column, kappa, estimate of the uncorrected irradiance OBC event discontinuity (as determined
  by get_obc_event_irradiance_discontinuities.pro), the pre-OBC event raypath (a0), and the post-OBC event raypath (a1) necessary to reconcile the
  pre- and post-OBC event calibrated irradiances.
plot_all_obc_event_raypath_corrections_with_parameters.pro: A wrapper to call get_obc_event_raypath_corrections.pro for the first nine OBC events.


SIMPLE "GETTERS" - Used by other IDL functions and procedures
-------------------------------------------------------------
get_obc_events.pro: Gets OBC event time data (date, start time, end time, etc.)
get_instrument_descriptor_from_mode_id.pro: Returns a structure consisting of two strings - a simple string (no whitespace, etc.)
  and a formatted string, both of which describe the sensor and can be used for plot titles, output file names, etc.
get_current_input_data_file.pro: Returns a string representing the file name of the currently valid data set matching specified
  parameters. This IDL function is a convenient place to track such files, which may evolve over time due to tests, evaluations,
  new data releases, etc.


MISCELLANEOUS
-------------
obc_event_raypath_corrections_inputs.pro: A list of input files used by get_obc_event_raypath_corrections.pro
plot_prism_degradation_example.pro: A "one-time use" procedure to plot examples of prism degradation. Plots prism degradation
  as a function of wavelength for selected SORCE mission days.


TEMPLATES - Not intended to be used directly from the command line (only by other IDL programs)
-----------------------------------------------------------------------------------------------
obc_event_template.sav
